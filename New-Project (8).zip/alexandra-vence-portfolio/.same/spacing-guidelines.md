# Spacing Guidelines

## Layout Spacing

### Page Structure
- **Max Content Width:** 1280px (container-xl)
- **Content Padding:**
  - Desktop: 4rem (64px) horizontal
  - Tablet: 2rem (32px) horizontal
  - Mobile: 1.5rem (24px) horizontal

### Section Spacing
- **Between Sections:** 6rem (96px) desktop, 4rem (64px) mobile
- **Section Top Padding:** 5rem (80px) desktop, 3rem (48px) mobile
- **Section Bottom Padding:** 5rem (80px) desktop, 3rem (48px) mobile

### Component Spacing
- **Card Internal Padding:** 2rem (32px)
- **Card Gap (Grid):** 2rem (32px) desktop, 1.5rem (24px) mobile
- **Text Block Spacing:** 1.5rem (24px) between paragraphs
- **List Item Spacing:** 1rem (16px) between items

### Typography Spacing
- **Heading to Subheading:** 0.5rem (8px)
- **Heading to Body:** 1.5rem (24px)
- **Paragraph to Paragraph:** 1rem (16px)
- **Caption to Element:** 0.5rem (8px)

## Responsive Breakpoints

```typescript
breakpoints: {
  'sm': '640px',   // Mobile landscape
  'md': '768px',   // Tablet
  'lg': '1024px',  // Desktop
  'xl': '1280px',  // Large desktop
  '2xl': '1536px', // Extra large
}
```

## Component-Specific Spacing

### Navigation
- **Nav Height:** 5rem (80px)
- **Nav Padding:** 1.5rem (24px) horizontal
- **Nav Link Spacing:** 2rem (32px) between links

### Hero Section
- **Vertical Padding:** 8rem (128px) desktop, 5rem (80px) mobile
- **Title to Subtitle:** 1.5rem (24px)
- **Text to CTA:** 2.5rem (40px)

### Feature Cards
- **Card Padding:** 2rem (32px)
- **Icon to Title:** 1.5rem (24px)
- **Title to Description:** 1rem (16px)
- **Card to Card:** 2rem (32px)

### Portfolio Grid
- **Grid Gap:** 2rem (32px) desktop, 1.5rem (24px) mobile
- **Image to Caption:** 1rem (16px)

### Contact Form
- **Input Spacing:** 1.5rem (24px) between fields
- **Label to Input:** 0.5rem (8px)
- **Form to Submit:** 2rem (32px)

### Footer
- **Top Padding:** 4rem (64px)
- **Bottom Padding:** 2rem (32px)
- **Column Gap:** 3rem (48px)
