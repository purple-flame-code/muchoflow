# Alexandra Vence Portfolio - Design Tokens

## Color Palette (LexVence Adaptation)

### Primary Colors

| Color Name | Hex Code | Usage | WCAG Contrast |
|------------|----------|-------|---------------|
| **Deep Blue** | `#0D1B2A` | Headings, Primary text, Dark accents | AAA on white (16.8:1) |
| **Burnt Gold** | `#CBA135` | CTA buttons, Links, Highlights | AA on white (3.2:1), AAA on deep-blue (7.8:1) |
| **Steel Gray** | `#E5E7EB` | Dividers, Subtle backgrounds | AA for borders |
| **Electric Blue** | `#2271FF` | Icons, Hover states, Interactive elements | AA on white (4.8:1) |

### Background & Text

| Element | Color | Notes |
|---------|-------|-------|
| **Main Background** | `#FAFAFA` | Soft off-white for reduced eye strain |
| **Body Text** | `#1A1A1A` | Near-black for readability (AAA: 19.5:1) |
| **Secondary Text** | `#2C2C2C` | Slightly lighter for hierarchy (AAA: 16.2:1) |
| **Muted Text** | `#6B7280` | Steel gray 500 for tertiary information |

### Accessibility Contrast Table

All combinations meet WCAG 2.1 AA minimum (4.5:1 for text, 3:1 for UI components):

| Foreground | Background | Contrast Ratio | WCAG Level |
|------------|------------|----------------|------------|
| Deep Blue | White/FAFAFA | 16.8:1 | AAA ✓ |
| Body Text | White/FAFAFA | 19.5:1 | AAA ✓ |
| Burnt Gold | Deep Blue | 7.8:1 | AAA ✓ |
| Electric Blue | White | 4.8:1 | AA ✓ |
| Burnt Gold | White | 3.2:1 | AA (Large text only) |

## Typography

### Font Pairings

**Sans-Serif (Primary):** Inter Variable
- Used for: Body text, UI elements, navigation
- Weights: 400 (Regular), 500 (Medium), 600 (Semibold), 700 (Bold)

**Serif (Accent):** Playfair Display
- Used for: Hero headings, section titles, elegant accents
- Weights: 400 (Regular), 600 (Semibold), 700 (Bold)

### Type Scale

| Element | Font | Size | Weight | Line Height | Letter Spacing |
|---------|------|------|--------|-------------|----------------|
| **Hero H1** | Playfair | 3.5rem (56px) | 700 | 1.1 | -0.02em |
| **Section H2** | Playfair | 2.5rem (40px) | 600 | 1.2 | -0.01em |
| **Subsection H3** | Inter | 1.75rem (28px) | 600 | 1.3 | -0.01em |
| **Card Title H4** | Inter | 1.25rem (20px) | 600 | 1.4 | 0 |
| **Body Large** | Inter | 1.125rem (18px) | 400 | 1.6 | 0 |
| **Body** | Inter | 1rem (16px) | 400 | 1.6 | 0 |
| **Small/Caption** | Inter | 0.875rem (14px) | 500 | 1.5 | 0.01em |
| **Button** | Inter | 1rem (16px) | 600 | 1 | 0.02em |

## Spacing System

Based on 8px grid for consistency:

| Token | Value | Usage |
|-------|-------|-------|
| `space-xs` | 0.5rem (8px) | Tight spacing, icon gaps |
| `space-sm` | 1rem (16px) | Small padding, inline spacing |
| `space-md` | 1.5rem (24px) | Card padding, element spacing |
| `space-lg` | 2rem (32px) | Section internal padding |
| `space-xl` | 3rem (48px) | Component separation |
| `space-2xl` | 4rem (64px) | Section vertical spacing |
| `space-3xl` | 6rem (96px) | Major section breaks |

## Border Radius

| Token | Value | Usage |
|-------|-------|-------|
| `rounded-sm` | 0.25rem (4px) | Small elements, badges |
| `rounded` | 0.5rem (8px) | Buttons, inputs |
| `rounded-lg` | 1rem (16px) | Cards, containers |
| `rounded-xl` | 1.5rem (24px) | Hero sections, featured elements |

## Shadows

Subtle, professional shadows for depth:

```css
shadow-sm: 0 1px 2px rgba(13, 27, 42, 0.05)
shadow: 0 2px 8px rgba(13, 27, 42, 0.08)
shadow-md: 0 4px 16px rgba(13, 27, 42, 0.1)
shadow-lg: 0 8px 32px rgba(13, 27, 42, 0.12)
```

## Animations

Subtle, refined motion:

| Animation | Duration | Easing | Usage |
|-----------|----------|--------|-------|
| Fade In | 600ms | ease-out | Page load, section reveals |
| Slide Up | 800ms | ease-out | Card entrance |
| Hover Scale | 200ms | ease-in-out | Interactive elements |
| Button Press | 150ms | ease-out | Click feedback |
